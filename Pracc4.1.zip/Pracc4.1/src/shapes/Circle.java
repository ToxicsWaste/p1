package shapes;
import static java.lang.Math.PI;

public class Circle extends Shape {
    private double radius;

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public Circle(){
        this.radius = radius;

    }
    @Override
    public String getType() {
        return ("Circle");
    }
    public double getPerimeter(){
        return  2*PI*radius;
    }

    @Override
    public double getArea() {
        return PI*Math.pow(radius,2);
    }

}
