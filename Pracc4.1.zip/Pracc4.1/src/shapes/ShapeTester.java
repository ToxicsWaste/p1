package shapes;

public class ShapeTester {
    public static void main(String[] args) {
        Circle c = new Circle();
        Rectangle rec = new Rectangle();
        Square sq = new Square();
        c.setRadius(5);
        rec.setSide1(12);
        rec.setSide2(15);
        sq.setSide1(10);
        System.out.println(c.getType());
        System.out.println("Circle area = " + c.getArea());
        System.out.println("Circle perimeter = " + c.getPerimeter());
        System.out.println("_________________");
        System.out.println(rec.getType());
        System.out.println("Area = " + rec.getArea());
        System.out.println("Perimeter =" + rec.getPerimeter());
        System.out.println("_____________");
        System.out.println(sq.getType());
        System.out.println("Area = " + sq.getArea());
        System.out.println("Perimeter = " + sq.getPerimeter());


    }
}
