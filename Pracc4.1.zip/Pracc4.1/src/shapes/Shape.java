package shapes;
public abstract   class Shape {
    public abstract String getType();
    public abstract double getArea();
    public abstract double getPerimeter();

    }

