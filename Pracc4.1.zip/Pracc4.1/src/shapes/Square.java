package shapes;

public class Square extends Shape {
    private double side1;


    public double getSide1() {
        return side1;
    }

    public void setSide1(double side1) {
        this.side1 = side1;
    }



    public Square(){
        this.side1 = side1;
    }

    @Override
    public String getType() {
        return ("Square");
    }

    @Override
    public double getArea() {
        return side1*side1;
    }

    @Override
    public double getPerimeter() {
        return 4*side1;
    }

}
